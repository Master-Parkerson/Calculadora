﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraSimple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //this.textBox1.Text = "0";
            this.textBox2.Text = "Calculadora";
        }
        String num1, num2;

        String[] separador = { "+", "-", "*", "/", "%", "^" };
        char[] separadorchar = {'+', '-', '*', '/', '%', '^' };
        
        //separador.
        //string[] words = textBox1.Text.Split(' ');

        //public string[] Words { get => words; set => words = value; }

        private void button4_Click(object sender, EventArgs e)
        {

            numeros("1");
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //this.textBox1.Text = "0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0") {

            }
            else
            {
                this.textBox1.Text = this.textBox1.Text + "0";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "0";
        }

        private void button5_Click(object sender, EventArgs e)
        {

            numeros("2");
        }

        private void button6_Click(object sender, EventArgs e)
        {

            numeros("3");
        }

        private void button7_Click(object sender, EventArgs e)
        {

            numeros("4");
        }

        public void numeros(string num)
        {
            if (this.textBox1.Text == "0")
            {
                this.textBox1.Text = num;
            }
            else
            {
                textBox1.Text = textBox1.Text + num;
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            numeros("5");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            numeros("6");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            numeros("7");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            numeros("8");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            numeros("9");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int n = textBox1.TextLength;
            //MessageBox.Show(n.ToString());
            
            if(n > 0)
            {  
                this.textBox1.Text = textBox1.Text.Substring(0, n - 1);
                if(this.textBox1.TextLength == 0)
                {
                    this.textBox1.Text = "0";
                }
            }else if(n == 0)
            {
                button1.Enabled = true;
            }
            //else if(n == )
            //{
            //    this.textBox1.Text = "0";
            //}
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //captura(this.textBox1.Text);
            Operadores("+");
            //this.textBox1.Text = textBox1.Text + " + ";
            //string[] words = phrase.Split(" + ");

        }

        public void Resultados(String ca)
        {
            int num = 0;
            String ca2 = ca;
            String datos2;
            
            //char[] separador = { ' ', '+', '-', '*', '/', '%', '^' };
            //num1 = ca;
            //String[] datos = ca.Split(separador, System.StringSplitOptions.RemoveEmptyEntries);
            String[] datos = { "" }; 
            //datos.Split("+");
            for (int i = 0; i < separadorchar.Length; i++)
            {
                datos = ca.Split(separadorchar[i]);
                // ca2 = ca.Split(separadorchar[i]);
                if (ca.Contains(separador[i].ToString()))
                {
                    //MessageBox.Show(separador[i].ToString());
                   //MessageBox.Show(separador[i].ToString());
                    //MessageBox.Show(num.ToString());
                    num = i;
                    break;
                }
                
                //Console.WriteLine(ca.Split(separadorchar[i]));
                //datos = ca.Split(separadorchar);

              
            }
            // Console.Write(ca.Count(separadorchar));
            //Console.WriteLine(datos);
           // MessageBox.Show(num.ToString());
           // MessageBox.Show(datos.ToString());
            Operaciones(datos[0], datos[1], separadorchar[num]);

        }

        public void Operaciones(String op1, String op2, char Result)
        {
            double a, b, c;
            a = double.Parse(op1);
            b = double.Parse(op2);

            switch (Result)
            {
                case '+':
                    c = a + b;
                    this.textBox1.Text = c.ToString();
                    
                    break;
                case '-':
                    this.textBox1.Text = $"{a - b}";
                    break;
                case '*':
                    this.textBox1.Text = $"{a * b}";
                    break;
                case '/':
                    this.textBox1.Text = $"{a / b}";
                    break;
                case '%':
                    this.textBox1.Text = $"{a % b}";
                    break;
                case '^':
                    this.textBox1.Text = $"{Math.Pow(a, b)}";
                    break;
               //case ''
                    /* case '!':
                    this.textBox1.Text = $"{a / b}";
                    for (i = 1; i <= número; i++)
                    {
                        hecho = hecho * i;
                    }
                    this. hecho);
                    break;
                    */

            }

        }
        public void Operadores(String op)
        {
            switch (op)
            {
                case "+":
                    this.textBox1.Text = textBox1.Text + " + ";
                    
                    break;
                case "-":
                    this.textBox1.Text = textBox1.Text + " - ";
                    break;
                case "*":
                    this.textBox1.Text = textBox1.Text + " * ";
                    break;
                case "/":
                    this.textBox1.Text = textBox1.Text + " / ";
                    break;
                case "%":
                    this.textBox1.Text = textBox1.Text + " % ";
                    break;
                case "^":
                    this.textBox1.Text = textBox1.Text + " ^ ";
                    break;


            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Operadores("-");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Operadores("/");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Operadores("*");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Operadores("%");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Operadores("^");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = "Calculadora";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                Resultados(this.textBox1.Text);
            } catch (Exception p)
            {
                this.textBox1.Text = "Error";
            }
        }
    }
}
